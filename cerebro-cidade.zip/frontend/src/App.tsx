import { useState } from "react";

import { Sidebar } from "./components/layout/Sidebar";
import { Header } from "./components/layout/Header";
import { Overview } from "./features/overview/Overview";
import { SmartMap } from "./features/smart-map/SmartMap";
import { Occurrences } from "./features/occurrences/Occurrences";
import { RiskAnalysis } from "./features/risk-analysis/RiskAnalysis";
import { UrbanMobility } from "./features/mobility/UrbanMobility";
import type { UrbanEvent } from "./features/overview/data/urbanEvents";

export type AppPage =
  | "overview"
  | "smart-map"
  | "occurrences"
  | "risk-analysis"
  | "mobility";

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activePage, setActivePage] = useState<AppPage>("overview");
  const [focusedEvent, setFocusedEvent] = useState<UrbanEvent | null>(null);

  function handleNavigate(page: AppPage) {
    if (page !== "smart-map") {
      setFocusedEvent(null);
    }
    setActivePage(page);
    setSidebarOpen(false);
  }

  function handleOpenEventInMap(event: UrbanEvent) {
    setFocusedEvent(event);
    setActivePage("smart-map");
  }

  return (
    <div className="app-shell">
      <Sidebar
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        activePage={activePage}
        onNavigate={handleNavigate}
      />

      <div className="app-main">
        <Header
          onMenuClick={() => setSidebarOpen(true)}
          activePage={activePage}
        />

        <main className="main-content">
          {activePage === "overview" && (
            <Overview
              onExploreMap={() => handleNavigate("smart-map")}
              onViewOccurrences={() => handleNavigate("occurrences")}
            />
          )}

          {activePage === "smart-map" && (
            <SmartMap initialEvent={focusedEvent} />
          )}

          {activePage === "occurrences" && (
            <Occurrences onOpenInMap={handleOpenEventInMap} />
          )}

          {activePage === "risk-analysis" && (
            <RiskAnalysis onOpenInMap={handleOpenEventInMap} />
          )}

          {activePage === "mobility" && (
            <UrbanMobility onOpenInMap={handleOpenEventInMap} />
          )}
        </main>
      </div>
    </div>
  );
}

export default App;
