import { useEffect, useRef, useState } from "react";
import { Menu, Bell, MapPin } from "lucide-react";

import { urbanEvents } from "../../features/overview/data/urbanEvents";
import type { UrbanEventCategory } from "../../features/overview/data/urbanEvents";
import type { AppPage } from "../../App";

interface HeaderProps {
  onMenuClick: () => void;
  activePage: AppPage;
}

const pageTitles: Record<AppPage, string> = {
  overview: "Visão geral",
  "smart-map": "Mapa inteligente",
  occurrences: "Ocorrências",
  "risk-analysis": "Análise de riscos",
  mobility: "Mobilidade urbana",
};

const categoryLabels: Record<UrbanEventCategory, string> = {
  traffic: "Trânsito",
  flood: "Alagamentos",
  incident: "Ocorrências",
};

const categoryColors: Record<UrbanEventCategory, string> = {
  traffic: "#D97732",
  flood: "#287CB5",
  incident: "#B94D4D",
};

export function Header({ onMenuClick, activePage }: HeaderProps) {
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const popoverRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!notificationsOpen) return;

    function handleClickOutside(event: MouseEvent) {
      if (
        popoverRef.current &&
        !popoverRef.current.contains(event.target as Node)
      ) {
        setNotificationsOpen(false);
      }
    }

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [notificationsOpen]);

  return (
    <header className="app-header">
      <div className="header-left">
        <button
          type="button"
          className="icon-button menu-button"
          onClick={onMenuClick}
          aria-label="Abrir menu"
        >
          <Menu size={19} />
        </button>

        <nav className="breadcrumb" aria-label="Navegação estrutural">
          <span className="breadcrumb-muted">Monitoramento</span>
          <span className="breadcrumb-separator">/</span>
          <span className="breadcrumb-current">{pageTitles[activePage]}</span>
        </nav>
      </div>

      <div className="header-actions">
        <div className="header-location-pill" title="Município monitorado">
          <MapPin size={13} strokeWidth={2} />
          <span>Curitiba · PR</span>
        </div>

        <div className="header-notification-wrapper" ref={popoverRef}>
          <button
            type="button"
            className={`notification-button ${notificationsOpen ? "active" : ""}`}
            onClick={() => setNotificationsOpen((prev) => !prev)}
            aria-label="Notificações de monitoramento"
            aria-expanded={notificationsOpen}
          >
            <Bell size={17} strokeWidth={1.9} />
            {urbanEvents.length > 0 && <span className="notification-dot" />}
          </button>

          {notificationsOpen && (
            <div className="header-notifications-popover">
              <div className="notifications-popover-header">
                <strong>Eventos em monitoramento</strong>
                <span>Demonstração</span>
              </div>

              <div className="notifications-popover-list">
                {urbanEvents.slice(0, 3).map((event) => (
                  <div className="notifications-popover-item" key={event.id}>
                    <span
                      className="notifications-popover-dot"
                      style={{
                        backgroundColor: categoryColors[event.category],
                      }}
                    />
                    <div>
                      <strong>{event.title}</strong>
                      <span>{categoryLabels[event.category]}</span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="notifications-popover-footer">
                {urbanEvents.length} registros ativos no painel
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
