import {
  ShieldAlert,
  LayoutDashboard,
  Map,
  Waves,
  AlertTriangle,
  Settings,
  ChevronLeft,
  Orbit,
  Bus,
} from "lucide-react";

import type { AppPage } from "../../App";

interface NavigationItem {
  id?: AppPage;
  name: string;
  icon: typeof LayoutDashboard;
  soon?: boolean;
}

interface NavigationSection {
  label: string;
  items: NavigationItem[];
}

const navigation: NavigationSection[] = [
  {
    label: "Monitoramento",
    items: [
      { id: "overview", name: "Visão geral", icon: LayoutDashboard },
      { id: "smart-map", name: "Mapa inteligente", icon: Map },
      { id: "occurrences", name: "Ocorrências", icon: AlertTriangle },
      { id: "mobility", name: "Mobilidade urbana", icon: Bus },
    ],
  },
  {
    label: "Inteligência",
    items: [
      { id: "risk-analysis", name: "Análise de riscos", icon: ShieldAlert },
    ],
  },
];

interface SidebarProps {
  open: boolean;
  onClose: () => void;
  activePage: AppPage;
  onNavigate: (page: AppPage) => void;
}

export function Sidebar({
  open,
  onClose,
  activePage,
  onNavigate,
}: SidebarProps) {
  return (
    <>
      {open && (
        <button
          type="button"
          className="sidebar-overlay"
          aria-label="Fechar menu"
          onClick={onClose}
        />
      )}

      <aside className={`sidebar ${open ? "sidebar-open" : ""}`}>
        <div className="sidebar-brand">
          <div className="brand-icon">
            <Orbit size={19} strokeWidth={2} />
          </div>

          <div className="brand-text">
            <span className="brand-name">CÉREBRO</span>
            <span className="brand-caption">INTELIGÊNCIA URBANA</span>
          </div>

          <button
            type="button"
            className="sidebar-close"
            onClick={onClose}
            aria-label="Fechar menu"
          >
            <ChevronLeft size={18} />
          </button>
        </div>

        <div className="sidebar-city">
          <div className="city-indicator" />

          <div className="city-information">
            <span className="city-name">Curitiba</span>
            <span className="city-region">Paraná, Brasil</span>
          </div>

          <span className="city-status-tag">Ativo</span>
        </div>

        <nav className="sidebar-navigation" aria-label="Menu principal">
          {navigation.map((section) => (
            <div className="navigation-section" key={section.label}>
              <span className="navigation-label">{section.label}</span>

              {section.items.map((item) => {
                const Icon = item.icon;
                const isActive = Boolean(item.id && item.id === activePage);

                return (
                  <button
                    key={item.name}
                    type="button"
                    className={`navigation-item ${
                      isActive ? "navigation-item-active" : ""
                    } ${item.soon ? "navigation-item-soon" : ""}`}
                    onClick={
                      item.id ? () => onNavigate(item.id as AppPage) : undefined
                    }
                    aria-disabled={item.soon || undefined}
                  >
                    <Icon size={17} strokeWidth={1.8} />
                    <span className="navigation-item-label">{item.name}</span>

                    {item.soon && (
                      <span className="navigation-badge">Em breve</span>
                    )}

                    {isActive && <span className="active-indicator" />}
                  </button>
                );
              })}
            </div>
          ))}
        </nav>

        <div className="sidebar-bottom">
          <button
            type="button"
            className="navigation-item navigation-item-soon"
            aria-disabled="true"
          >
            <Settings size={17} strokeWidth={1.8} />
            <span className="navigation-item-label">Configurações</span>
            <span className="navigation-badge">Em breve</span>
          </button>

          <div className="sidebar-footer">
            <div className="sidebar-footer-top">
              <span className="sidebar-footer-dot" />
              <span className="footer-user-name">Cérebro da Cidade</span>
            </div>
            <span className="footer-user-role">
              Núcleo de monitoramento · PR
            </span>
          </div>
        </div>
      </aside>
    </>
  );
}
